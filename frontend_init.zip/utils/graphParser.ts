import { Node, Edge } from 'reactflow';
import { TrainingConfig, ScriptType } from '../types';
import { SCRIPTS, DEFAULT_GLOBAL_CONFIG } from '../constants';

export const parseGraph = (nodes: Node[], edges: Edge[]): { config: TrainingConfig, command: string } => {
  const scriptNode = nodes.find(n => n.type === 'scriptNode');
  
  if (!scriptNode) {
    return { config: {} as any, command: "Error: No Script Node found." };
  }

  const scriptName = scriptNode.data.scriptName || SCRIPTS[0].name;
  const configPath = scriptNode.data.configPath || "config.json";
  const scriptType = SCRIPTS.find(s => s.name === scriptName)?.type || ScriptType.OLD;

  let config: TrainingConfig = {
    script: scriptName,
    config_path: configPath,
    ...DEFAULT_GLOBAL_CONFIG
  };

  // Helper: Find target node connected to a specific Source Handle on Script Node
  const mergeFromSourceHandle = (handleId: string) => {
      // Find edge where Source is ScriptNode and SourceHandle is handleId
      const edge = edges.find(e => e.source === scriptNode.id && e.sourceHandle === handleId);
      if (edge) {
          const node = nodes.find(n => n.id === edge.target);
          if (node) {
              if (node.type === 'oldSchemaRoot') {
                  // Do not merge root data directly into config, root is a router.
              } else {
                  const { onChange, label, slots, ...data } = node.data;
                  config = { ...config, ...data };
              }
          }
      }
  };

  mergeFromSourceHandle('dir_out');
  mergeFromSourceHandle('lora_out');
  mergeFromSourceHandle('misc_out');

  // --- TRAVERSAL LOGIC FOR LISTS (Abstract -> Detail) ---

  // Helper: Get all items connected to a List Node's output slots
  // Structure: List (Source) -> [Edges] -> Items (Targets)
  const parseListItems = (listNodeId: string, itemProcessor: (node: Node) => any) => {
      const listNode = nodes.find(n => n.id === listNodeId);
      if(!listNode || !listNode.data.slots) return [];
      
      const results: any[] = [];
      
      listNode.data.slots.forEach((slotId: string) => {
          // Find edge where Source is List and SourceHandle is Slot
          const edge = edges.find(e => e.source === listNodeId && e.sourceHandle === slotId);
          if(edge) {
              const itemNode = nodes.find(n => n.id === edge.target);
              if(itemNode) {
                  const processed = itemProcessor(itemNode);
                  if(processed) results.push(processed);
              }
          }
      });
      return results;
  }

  // Helper: Find the List Node connected to a specific output handle of a Parent Node
  const getConnectedListResult = (parentNodeId: string, handleId: string, itemProcessor: (node: Node) => any) => {
      const edge = edges.find(e => e.source === parentNodeId && e.sourceHandle === handleId);
      if(!edge) return null;
      return parseListItems(edge.target, itemProcessor);
  }

  // --- PARSE NEW SCHEMA (dataset_configs) ---
  const dsEdge = edges.find(e => e.source === scriptNode.id && e.sourceHandle === 'json_out');
  
  if (dsEdge) {
    const targetNode = nodes.find(n => n.id === dsEdge.target);
    
    if (targetNode && (targetNode.type === 'datasetListNode' || targetNode.type === 'datasetConfigNode')) {
        config.dataset_configs = [];
        
        const buildDataset = (dsNode: Node) => {
            const d: any = {
                train_data_dir: dsNode.data.train_data_dir,
                resolution: dsNode.data.resolution || config.resolution,
                recreate_cache: false,
                repeats: dsNode.data.repeats || 1,
            };
            if(dsNode.data.recreate_cache_target) d.recreate_cache_target = true;
            if(dsNode.data.recreate_cache_reference) d.recreate_cache_reference = true;
            if(dsNode.data.recreate_cache_caption) d.recreate_cache_caption = true;

            const imgs = getConnectedListResult(dsNode.id, 'image_config', (n) => (n.data.key && n.data.suffix) ? { [n.data.key]: { suffix: n.data.suffix } } : null);
            if(imgs && imgs.length > 0) d.image_configs = Object.assign({}, ...imgs);

            const targets = getConnectedListResult(dsNode.id, 'target_config', (n) => (n.data.key) ? { key: n.data.key, val: { image: n.data.image, from_image: n.data.from_image } } : null);
            if(targets && targets.length > 0) {
                d.target_configs = {};
                targets.forEach((t: any) => {
                    if(!d.target_configs[t.key]) d.target_configs[t.key] = [];
                    const obj: any = { image: t.val.image };
                    if(t.val.from_image) obj.from_image = t.val.from_image;
                    d.target_configs[t.key].push(obj);
                });
            }

            const refs = getConnectedListResult(dsNode.id, 'reference_config', (refGroupNode) => {
                    if (!refGroupNode.data.key) return null;
                    const entries = parseListItems(refGroupNode.id, (entryNode) => {
                        const e = { ...entryNode.data };
                        delete e.label;
                        if(e.sample_type === 'from_same_name') return { sample_type: 'from_same_name', image: e.image };
                        return { sample_type: e.sample_type, image: e.image, suffix: e.suffix, resize: e.resize, count: e.count };
                    });
                    return (entries.length > 0) ? { key: refGroupNode.data.key, entries: entries } : null;
            });
            if(refs && refs.length > 0) {
                d.reference_configs = {};
                refs.forEach((r: any) => {
                        if(!d.reference_configs[r.key]) d.reference_configs[r.key] = [];
                        d.reference_configs[r.key] = [...d.reference_configs[r.key], ...r.entries];
                });
            }

            const caps = getConnectedListResult(dsNode.id, 'caption_config', (n) => {
                if(!n.data.key) return null;
                const obj: any = { ext: n.data.ext, image: n.data.image };
                if(n.data.reference_list) obj.reference_list = n.data.reference_list;
                return { [n.data.key]: obj };
            });
            if(caps && caps.length > 0) d.caption_configs = Object.assign({}, ...caps);

            const batches = getConnectedListResult(dsNode.id, 'batch_config', (n) => {
                    const clean = { target_config: n.data.target_config, caption_config: n.data.caption_config, caption_dropout: n.data.caption_dropout };
                    if(n.data.reference_config) (clean as any).reference_config = n.data.reference_config;
                    return clean;
            });
            if(batches && batches.length > 0) d.batch_configs = batches;
            return d;
        }

        if (targetNode.type === 'datasetListNode') {
            config.dataset_configs = parseListItems(targetNode.id, buildDataset);
        } else if (targetNode.type === 'datasetConfigNode') {
            config.dataset_configs.push(buildDataset(targetNode));
        }
    }
  }

  // --- PARSE OLD SCHEMA (root merge) ---
  const oldEdge = edges.find(e => e.source === scriptNode.id && e.sourceHandle === 'old_out');
  
  if (oldEdge) {
    const targetNode = nodes.find(n => n.id === oldEdge.target);

    if (targetNode && targetNode.type === 'oldSchemaRoot') {
        
        // A. Image Configs
        const imgConfigs = getConnectedListResult(targetNode.id, 'image_configs', (n) => {
            return (n.data.key) ? { [n.data.key]: { suffix: n.data.suffix } } : null;
        });
        if(imgConfigs && imgConfigs.length > 0) config.image_configs = Object.assign({}, ...imgConfigs);

        // B. Caption Configs
        const capConfigs = getConnectedListResult(targetNode.id, 'caption_configs', (n) => {
            if(!n.data.key) return null;
            const obj: any = {};
            if(n.data.ext) obj.ext = n.data.ext;
            if(n.data.instruction) obj.instruction = n.data.instruction;
            
            // Check for Nested Reference List (Caption Item -> Ref List -> Ref Item)
            const refListItems = getConnectedListResult(n.id, 'ref_list', (refItem) => {
                 const r: any = { target: refItem.data.target };
                 if(refItem.data.resize) r.resize = refItem.data.resize;
                 if(refItem.data.dropout !== undefined) r.dropout = refItem.data.dropout;
                 return r;
            });
            
            if(refListItems && refListItems.length > 0) {
                obj.ref_image_config = { ref_image_list: refListItems };
            }
            return { [n.data.key]: obj };
        });
        if(capConfigs && capConfigs.length > 0) config.caption_configs = Object.assign({}, ...capConfigs);

        // C. Training Set
        const trainingSet = getConnectedListResult(targetNode.id, 'training_set', (n) => {
            const setObj: any = {};
            if(n.data.captions_selection_target) {
                setObj.captions_selection = { target: n.data.captions_selection_target };
            }

            // Nested Layouts (Training Set Item -> Layout List -> Layout Item)
            const layouts = getConnectedListResult(n.id, 'layout_list', (l) => {
                if(!l.data.key) return null;
                const lo: any = { target: l.data.target };
                if(l.data.noised) lo.noised = true;
                if(l.data.dropout !== undefined) lo.dropout = l.data.dropout;
                return { [l.data.key]: lo };
            });

            if(layouts && layouts.length > 0) {
                setObj.training_layout_configs = Object.assign({}, ...layouts);
            }
            return setObj;
        });
        if(trainingSet && trainingSet.length > 0) config.training_set = trainingSet;
    }
  }

  const cmd = `python ${scriptName} --config_path ${configPath}`;
  return { config, command: cmd };
};
