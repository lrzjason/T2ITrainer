import React, { useCallback, useState, useEffect, useRef } from 'react';
import ReactFlow, { 
  addEdge, 
  Background, 
  Connection, 
  Node,
  Edge,
  applyNodeChanges,
  applyEdgeChanges,
  NodeChange,
  EdgeChange,
  OnNodesChange,
  OnEdgesChange,
  SelectionMode,
  useReactFlow,
  OnConnectStartParams
} from 'reactflow';
import { 
    LayoutGrid, 
    Terminal, 
    Save, 
    FolderOpen, 
    X,
    Moon,
    Sun,
    Info,
    Github,
    Box,
    Layers,
    Component,
    Settings,
    Play
} from 'lucide-react';

import { ScriptNode } from './nodes/ScriptNode';
import { DirectoryNode, LoRANode, MiscNode, ConfigTemplateNode } from './nodes/GlobalSectionNodes';
import { 
    OldSchemaRootNode,
    OldImageListNode, OldImageItemNode,
    OldCaptionListNode, OldCaptionItemNode, OldRefImageListNode, OldRefImageItemNode,
    OldTrainingSetListNode, OldTrainingSetItemNode, OldLayoutListNode, OldLayoutItemNode
} from './nodes/OldSchemaNodes';
import { DatasetConfigNode, DatasetListNode } from './nodes/NewSchemaNodes';
import { 
    ImageConfigNode, ImageListNode,
    TargetConfigNode, TargetListNode,
    ReferenceConfigNode, ReferenceListNode, ReferenceEntryNode,
    CaptionConfigNode, CaptionListNode,
    BatchConfigNode, BatchListNode
} from './nodes/ConfigSectionNodes';
import { parseGraph } from '../utils/graphParser';
import { DEFAULT_GLOBAL_CONFIG, SCRIPTS, TRANSLATIONS } from '../constants';
import { FlowContext, Language, Theme } from './FlowContext';

// Logic for Auto-Connecting Nodes
const NODE_CONNECTION_MAP: Record<string, Record<string, { type: string; label: string }[]>> = {
  scriptNode: {
    dir_out: [{ type: 'directoryNode', label: 'Directory Setup' }],
    lora_out: [{ type: 'loraNode', label: 'LoRA Config' }],
    misc_out: [{ type: 'miscNode', label: 'Misc Settings' }],
    json_out: [{ type: 'datasetListNode', label: 'Dataset List' }],
    old_out: [{ type: 'oldSchemaRoot', label: 'Old Schema Root' }],
  },
  datasetListNode: {
    __default__: [{ type: 'datasetConfigNode', label: 'Dataset Config' }]
  },
  datasetConfigNode: {
    image_config: [{ type: 'imageListNode', label: 'Image List' }],
    target_config: [{ type: 'targetListNode', label: 'Target List' }],
    reference_config: [{ type: 'referenceListNode', label: 'Ref List' }],
    caption_config: [{ type: 'captionListNode', label: 'Caption List' }],
    batch_config: [{ type: 'batchListNode', label: 'Batch List' }]
  },
  imageListNode: { __default__: [{ type: 'imageConfigNode', label: 'Image Item' }] },
  targetListNode: { __default__: [{ type: 'targetConfigNode', label: 'Target Item' }] },
  referenceListNode: { __default__: [{ type: 'referenceConfigNode', label: 'Ref Group' }] },
  captionListNode: { __default__: [{ type: 'captionConfigNode', label: 'Caption Item' }] },
  batchListNode: { __default__: [{ type: 'batchConfigNode', label: 'Batch Item' }] },
  referenceConfigNode: { __default__: [{ type: 'referenceEntryNode', label: 'Ref Source' }] },
  
  oldSchemaRoot: {
    image_configs: [{ type: 'oldImageListNode', label: 'Image List (Old)' }],
    caption_configs: [{ type: 'oldCaptionListNode', label: 'Caption List (Old)' }],
    training_set: [{ type: 'oldTrainingSetListNode', label: 'Training Set List (Old)' }]
  },
  oldImageListNode: { __default__: [{ type: 'oldImageItemNode', label: 'Image Item (Old)' }] },
  oldCaptionListNode: { __default__: [{ type: 'oldCaptionItemNode', label: 'Caption Item (Old)' }] },
  oldCaptionItemNode: { ref_list: [{ type: 'oldRefImageListNode', label: 'Ref Image List (Old)' }] },
  oldRefImageListNode: { __default__: [{ type: 'oldRefImageItemNode', label: 'Ref Image Item (Old)' }] },
  oldTrainingSetListNode: { __default__: [{ type: 'oldTrainingSetItemNode', label: 'Training Set Item (Old)' }] },
  oldTrainingSetItemNode: { layout_list: [{ type: 'oldLayoutListNode', label: 'Layout List (Old)' }] },
  oldLayoutListNode: { __default__: [{ type: 'oldLayoutItemNode', label: 'Layout Item (Old)' }] }
};

const nodeTypes = {
  scriptNode: ScriptNode,
  directoryNode: DirectoryNode,
  loraNode: LoRANode,
  miscNode: MiscNode,
  configTemplateNode: ConfigTemplateNode,
  
  // New Schema Nodes
  datasetConfigNode: DatasetConfigNode,
  datasetListNode: DatasetListNode,
  imageConfigNode: ImageConfigNode, imageListNode: ImageListNode,
  targetConfigNode: TargetConfigNode, targetListNode: TargetListNode,
  referenceConfigNode: ReferenceConfigNode, referenceListNode: ReferenceListNode, referenceEntryNode: ReferenceEntryNode,
  captionConfigNode: CaptionConfigNode, captionListNode: CaptionListNode,
  batchConfigNode: BatchConfigNode, batchListNode: BatchListNode,

  // Old Schema Nodes
  oldSchemaRoot: OldSchemaRootNode,
  oldImageListNode: OldImageListNode, oldImageItemNode: OldImageItemNode,
  oldCaptionListNode: OldCaptionListNode, oldCaptionItemNode: OldCaptionItemNode, oldRefImageListNode: OldRefImageListNode, oldRefImageItemNode: OldRefImageItemNode,
  oldTrainingSetListNode: OldTrainingSetListNode, oldTrainingSetItemNode: OldTrainingSetItemNode, oldLayoutListNode: OldLayoutListNode, oldLayoutItemNode: OldLayoutItemNode
};

const initialNodes: Node[] = [
  // Source (Left)
  { id: 'script', type: 'scriptNode', position: { x: 50, y: 300 }, data: { scriptName: SCRIPTS[2].name, configPath: "config_new.json" } },
  
  // First Layer (Target)
  { id: 'dir', type: 'directoryNode', position: { x: 450, y: 50 }, data: { ...DEFAULT_GLOBAL_CONFIG } },
  { id: 'lora', type: 'loraNode', position: { x: 450, y: 350 }, data: { ...DEFAULT_GLOBAL_CONFIG } },
  { id: 'misc', type: 'miscNode', position: { x: 450, y: 650 }, data: { ...DEFAULT_GLOBAL_CONFIG } },
  { id: 'ds_list', type: 'datasetListNode', position: { x: 450, y: 1000 }, data: { slots: ['dataset_0'] } },
  
  // Second Layer (Target of List)
  { id: 'dataset', type: 'datasetConfigNode', position: { x: 800, y: 1000 }, data: { train_data_dir: "F:/ImageSet/longcat" } },

  // Third Layer (Component Lists)
  { id: 'img_list', type: 'imageListNode', position: { x: 1200, y: 800 }, data: { slots: ['img_0'] } },
  { id: 'tgt_list', type: 'targetListNode', position: { x: 1200, y: 1000 }, data: { slots: ['tgt_0'] } },
  { id: 'ref_list', type: 'referenceListNode', position: { x: 1200, y: 1200 }, data: { slots: ['ref_0'] } },
  { id: 'cap_list', type: 'captionListNode', position: { x: 1200, y: 1500 }, data: { slots: ['cap_0'] } },
  { id: 'batch_list', type: 'batchListNode', position: { x: 1200, y: 1800 }, data: { slots: ['batch_0'] } },

  // Fourth Layer (Items)
  { id: 'img_1', type: 'imageConfigNode', position: { x: 1600, y: 800 }, data: { key: 'train', suffix: '_T' } },
  { id: 'tgt_1', type: 'targetConfigNode', position: { x: 1600, y: 1000 }, data: { key: 'train', image: 'train', from_image: '' } },
  
  // Reference Split: Group + Entry
  { id: 'ref_group_1', type: 'referenceConfigNode', position: { x: 1600, y: 1200 }, data: { key: 'train_ref', slots: ['entry_0'] } },
  { id: 'ref_entry_1', type: 'referenceEntryNode', position: { x: 1950, y: 1200 }, data: { sample_type: 'from_same_name', image: 'train' } },

  { id: 'cap_1', type: 'captionConfigNode', position: { x: 1600, y: 1500 }, data: { key: 'train', ext: '.txt', image: 'train' } },
  { id: 'batch_1', type: 'batchConfigNode', position: { x: 1600, y: 1800 }, data: { target_config: 'train', caption_config: 'train', caption_dropout: 0.1 } },
];

const initialEdges: Edge[] = [
    // Script (Source Right) -> Global (Target Left)
    { id: 'e1', source: 'script', sourceHandle: 'dir_out', target: 'dir', targetHandle: 'in' },
    { id: 'e2', source: 'script', sourceHandle: 'lora_out', target: 'lora', targetHandle: 'in' },
    { id: 'e3', source: 'script', sourceHandle: 'misc_out', target: 'misc', targetHandle: 'in' },
    { id: 'e4', source: 'script', sourceHandle: 'json_out', target: 'ds_list', targetHandle: 'in' },
    
    // Dataset List (Source Right) -> Dataset (Target Left)
    { id: 'e5', source: 'ds_list', sourceHandle: 'dataset_0', target: 'dataset', targetHandle: 'in' },
    
    // Dataset (Source Right) -> Component Lists (Target Left)
    { id: 'e6', source: 'dataset', sourceHandle: 'image_config', target: 'img_list', targetHandle: 'in' },
    { id: 'e7', source: 'dataset', sourceHandle: 'target_config', target: 'tgt_list', targetHandle: 'in' },
    { id: 'e8', source: 'dataset', sourceHandle: 'reference_config', target: 'ref_list', targetHandle: 'in' },
    { id: 'e9', source: 'dataset', sourceHandle: 'caption_config', target: 'cap_list', targetHandle: 'in' },
    { id: 'e10', source: 'dataset', sourceHandle: 'batch_config', target: 'batch_list', targetHandle: 'in' },
    
    // Component List (Source Right) -> Item (Target Left)
    { id: 'e11', source: 'img_list', sourceHandle: 'img_0', target: 'img_1', targetHandle: 'in' },
    { id: 'e12', source: 'tgt_list', sourceHandle: 'tgt_0', target: 'tgt_1', targetHandle: 'in' },
    
    // Reference: List -> Group -> Entry
    { id: 'e13', source: 'ref_list', sourceHandle: 'ref_0', target: 'ref_group_1', targetHandle: 'in' },
    { id: 'e13b', source: 'ref_group_1', sourceHandle: 'entry_0', target: 'ref_entry_1', targetHandle: 'in' },

    { id: 'e14', source: 'cap_list', sourceHandle: 'cap_0', target: 'cap_1', targetHandle: 'in' },
    { id: 'e15', source: 'batch_list', sourceHandle: 'batch_0', target: 'batch_1', targetHandle: 'in' },
];

const defaultEdgeOptions = {
    type: 'default',
    animated: false,
    style: { strokeWidth: 2, stroke: '#a1a1aa' },
    interactionWidth: 15,
};

// --- About & Docs Modal ---
const AboutModal = ({ onClose }: { onClose: () => void }) => {
    const [activeTab, setActiveTab] = useState<'about' | 'docs'>('about');

    const DocSection = ({ title, icon: Icon, children }: any) => (
        <div className="mb-6">
            <h4 className="text-base font-bold text-zinc-900 dark:text-zinc-100 mb-3 flex items-center gap-2 border-b border-zinc-200 dark:border-zinc-800 pb-1">
                <Icon size={18} className="text-blue-500"/> {title}
            </h4>
            <div className="space-y-4">
                {children}
            </div>
        </div>
    );

    const NodeDoc = ({ title, inputs, fields, desc }: any) => (
        <div className="bg-zinc-50 dark:bg-zinc-900/50 p-3 rounded-lg border border-zinc-100 dark:border-zinc-800">
            <h5 className="font-bold text-zinc-800 dark:text-zinc-200 text-sm mb-1">{title}</h5>
            {desc && <p className="text-xs text-zinc-500 mb-2 italic">{desc}</p>}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                {inputs && inputs.length > 0 && (
                     <div>
                        <span className="font-semibold text-emerald-600 dark:text-emerald-400">Inputs:</span> 
                        <span className="text-zinc-600 dark:text-zinc-400 ml-1">{inputs.join(', ')}</span>
                     </div>
                )}
                {fields && fields.length > 0 && (
                     <div>
                        <span className="font-semibold text-blue-600 dark:text-blue-400">Fields:</span>
                        <span className="text-zinc-600 dark:text-zinc-400 ml-1">{fields.join(', ')}</span>
                     </div>
                )}
            </div>
        </div>
    );

    return (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
            <div className="bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[85vh] flex flex-col overflow-hidden">
                {/* Header */}
                <div className="flex border-b border-zinc-200 dark:border-zinc-800 bg-white/50 dark:bg-zinc-900/50 backdrop-blur-md">
                    <button 
                        onClick={() => setActiveTab('about')}
                        className={`flex-1 py-4 text-sm font-bold uppercase tracking-wider transition-all ${activeTab === 'about' ? 'bg-zinc-50 dark:bg-zinc-900/50 text-blue-600 dark:text-blue-400 border-b-2 border-blue-500' : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 hover:bg-zinc-50/50 dark:hover:bg-zinc-800/50'}`}
                    >
                        About & Contact
                    </button>
                    <button 
                        onClick={() => setActiveTab('docs')}
                        className={`flex-1 py-4 text-sm font-bold uppercase tracking-wider transition-all ${activeTab === 'docs' ? 'bg-zinc-50 dark:bg-zinc-900/50 text-emerald-600 dark:text-emerald-400 border-b-2 border-emerald-500' : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200 hover:bg-zinc-50/50 dark:hover:bg-zinc-800/50'}`}
                    >
                        Node Documentation
                    </button>
                    <button onClick={onClose} className="px-6 text-zinc-400 hover:text-red-500 dark:hover:text-red-400 transition-colors border-l border-zinc-200 dark:border-zinc-800">
                        <X size={20}/>
                    </button>
                </div>

                {/* Content Area */}
                <div className="overflow-y-auto p-6 scrollbar-thin bg-white dark:bg-zinc-950">
                    {activeTab === 'about' ? (
                        <div className="space-y-10 text-zinc-700 dark:text-zinc-300 max-w-3xl mx-auto">
                            {/* Repo Info */}
                            <section className="text-center">
                                <h3 className="text-xl font-bold text-zinc-900 dark:text-white mb-2 flex items-center justify-center gap-2">
                                    <Github size={24}/> T2ITrainer Repository
                                </h3>
                                <a href="https://github.com/lrzjason/T2ITrainer" target="_blank" rel="noreferrer" className="text-blue-500 hover:text-blue-600 hover:underline font-mono text-sm bg-blue-50 dark:bg-blue-900/20 px-3 py-1 rounded-full">
                                    https://github.com/lrzjason/T2ITrainer
                                </a>
                            </section>

                            <div className="w-full h-px bg-zinc-200 dark:bg-zinc-800"></div>

                            {/* Contact Info */}
                            <section>
                                <h3 className="text-lg font-bold text-zinc-900 dark:text-white mb-6 flex items-center gap-2">
                                    📬 Contact Information
                                </h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="bg-zinc-50 dark:bg-zinc-900 p-4 rounded-xl border border-zinc-100 dark:border-zinc-800 flex items-center gap-3">
                                        <span className="font-bold text-zinc-500 text-xs uppercase w-20">Twitter</span>
                                        <a href="https://twitter.com/Lrzjason" target="_blank" rel="noreferrer" className="text-blue-500 font-medium hover:underline">@Lrzjason</a>
                                    </div>
                                    <div className="bg-zinc-50 dark:bg-zinc-900 p-4 rounded-xl border border-zinc-100 dark:border-zinc-800 flex items-center gap-3">
                                        <span className="font-bold text-zinc-500 text-xs uppercase w-20">Email</span>
                                        <a href="mailto:lrzjason@gmail.com" className="text-blue-500 font-medium hover:underline">lrzjason@gmail.com</a>
                                    </div>
                                    <div className="bg-zinc-50 dark:bg-zinc-900 p-4 rounded-xl border border-zinc-100 dark:border-zinc-800 flex items-center gap-3">
                                        <span className="font-bold text-zinc-500 text-xs uppercase w-20">QQ Group</span>
                                        <span className="font-mono">866612947</span>
                                    </div>
                                    <div className="bg-zinc-50 dark:bg-zinc-900 p-4 rounded-xl border border-zinc-100 dark:border-zinc-800 flex items-center gap-3">
                                        <span className="font-bold text-zinc-500 text-xs uppercase w-20">WeChat ID</span>
                                        <span className="font-mono">fkdeai</span>
                                    </div>
                                    <div className="bg-zinc-50 dark:bg-zinc-900 p-4 rounded-xl border border-zinc-100 dark:border-zinc-800 flex items-center gap-3">
                                        <span className="font-bold text-zinc-500 text-xs uppercase w-20">CivitAI</span>
                                        <a href="https://civitai.com/user/xiaozhijason" target="_blank" rel="noreferrer" className="text-blue-500 font-medium hover:underline">xiaozhijason</a>
                                    </div>
                                    <div className="bg-zinc-50 dark:bg-zinc-900 p-4 rounded-xl border border-zinc-100 dark:border-zinc-800 flex items-center gap-3">
                                        <span className="font-bold text-zinc-500 text-xs uppercase w-20">Bilibili</span>
                                        <a href="https://space.bilibili.com/443010" target="_blank" rel="noreferrer" className="text-blue-500 font-medium hover:underline">小志Jason</a>
                                    </div>
                                </div>
                            </section>

                            <div className="w-full h-px bg-zinc-200 dark:bg-zinc-800"></div>

                            {/* Sponsor Info */}
                            <section>
                                <h3 className="text-lg font-bold text-zinc-900 dark:text-white mb-6 text-center">
                                    ❤️ Sponsor me for more open source projects
                                </h3>
                                <div className="flex flex-col md:flex-row gap-8 justify-center items-center bg-zinc-50 dark:bg-zinc-900/30 p-8 rounded-2xl border border-zinc-200 dark:border-zinc-800">
                                    <div className="text-center group">
                                        <div className="bg-white p-2 rounded-xl shadow-sm mb-3 group-hover:shadow-md transition-shadow">
                                            <img src="https://github.com/lrzjason/Comfyui-In-Context-Lora-Utils/blob/main/image/bmc_qr.png?raw=true" alt="Buy Me a Coffee QR" className="w-40 h-40 object-contain mix-blend-multiply dark:mix-blend-normal" />
                                        </div>
                                        <p className="font-bold text-xs uppercase tracking-wide text-zinc-500">Buy me a coffee</p>
                                    </div>
                                    <div className="w-px h-32 bg-zinc-200 dark:bg-zinc-700 hidden md:block"></div>
                                    <div className="text-center group">
                                        <div className="bg-white p-2 rounded-xl shadow-sm mb-3 group-hover:shadow-md transition-shadow">
                                            <img src="https://github.com/lrzjason/Comfyui-In-Context-Lora-Utils/blob/main/image/wechat.jpg?raw=true" alt="WeChat QR" className="w-40 h-40 object-contain mix-blend-multiply dark:mix-blend-normal" />
                                        </div>
                                        <p className="font-bold text-xs uppercase tracking-wide text-zinc-500">WeChat</p>
                                    </div>
                                </div>
                            </section>
                        </div>
                    ) : (
                        <div className="max-w-4xl mx-auto pb-10">
                            <p className="mb-6 text-sm text-zinc-500 dark:text-zinc-400 bg-blue-50 dark:bg-blue-900/20 p-3 rounded border border-blue-100 dark:border-blue-900/50">
                                <Info size={16} className="inline mr-2 text-blue-500 mb-0.5"/>
                                The following documentation details the inputs and configuration fields for every node type in the editor.
                            </p>
                            
                            <DocSection title="Core Nodes" icon={Terminal}>
                                <NodeDoc 
                                    title="Script Loader"
                                    desc="The main entry point for generating the training command and configuration file."
                                    fields={['Python Script', 'Config Path (Output)']}
                                    inputs={['Connect to: Directory Setup, LoRA Config, Misc Settings, Dataset List, Old Schema Root']}
                                />
                                <NodeDoc 
                                    title="Directory Setup"
                                    desc="Defines global paths for models and output data."
                                    inputs={['From Script']}
                                    fields={['Pretrained Model Path', 'Output Dir', 'Logging Dir', 'Save Name', 'Global Data Dir', 'Model Path', 'VAE Path']}
                                />
                                <NodeDoc 
                                    title="LoRA Config"
                                    desc="Network configuration for LoRA training."
                                    inputs={['From Script']}
                                    fields={['Rank', 'Alpha', 'Use LoKR', 'LoKR Factor', 'LoRA Layers']}
                                />
                                <NodeDoc 
                                    title="Misc Settings"
                                    desc="General hyperparameters and advanced training settings."
                                    inputs={['From Script']}
                                    fields={['Resolution', 'Batch Size', 'Epochs', 'Learning Rate', 'Optimizer', 'Precision', 'Scheduler', 'Seed', 'Caption Dropout', 'Save Every N Epochs', 'Blocks to Swap', 'Gradient Checkpointing', 'Recreate Cache', 'Validation Epochs', 'Validation Ratio', 'Weighting Scheme', 'NLN Config']}
                                />
                            </DocSection>

                            <DocSection title="Structure Nodes (New Schema)" icon={Layers}>
                                <NodeDoc 
                                    title="Dataset List"
                                    desc="Aggregates multiple dataset configurations."
                                    inputs={['From Script']}
                                    fields={['Add/Remove Dataset Slots']}
                                />
                                <NodeDoc 
                                    title="Dataset Configuration"
                                    desc="Configuration for a specific dataset block. Acts as a hub for component lists."
                                    inputs={['From Dataset List']}
                                    fields={['Data Directory', 'Repeats', 'Resolution', 'Recreate Cache (Target/Ref/Cap)']}
                                />
                            </DocSection>

                            <DocSection title="Component Nodes" icon={Component}>
                                <NodeDoc 
                                    title="Lists (Image, Target, Caption, Batch, Reference)"
                                    desc="Intermediate nodes that manage lists of specific items. Connects Dataset Config to individual Items."
                                    inputs={['From Dataset Config']}
                                    fields={['Add/Remove Slots']}
                                />
                                <NodeDoc 
                                    title="Image Item"
                                    desc="Defines image processing rules."
                                    inputs={['From Image List']}
                                    fields={['Image Name (Key)', 'Suffix']}
                                />
                                <NodeDoc 
                                    title="Target Item"
                                    desc="Defines target image pairs for training."
                                    inputs={['From Target List']}
                                    fields={['Target Name (Key)', 'Image', 'From Image']}
                                />
                                <NodeDoc 
                                    title="Reference Group"
                                    desc="Aggregates multiple reference sources under a single key."
                                    inputs={['From Reference List']}
                                    fields={['Reference Name (Key)']}
                                />
                                <NodeDoc 
                                    title="Reference Source"
                                    desc="A specific source of reference images."
                                    inputs={['From Reference Group']}
                                    fields={['Sample Type (same_name/subdir)', 'Image Name', 'Suffix', 'Resize', 'Count']}
                                />
                                <NodeDoc 
                                    title="Caption Item"
                                    desc="Defines captioning rules and optional reference lists."
                                    inputs={['From Caption List']}
                                    fields={['Caption Name (Key)', 'Extension', 'Image', 'Include Reference List (Ref Name, Dropout, Resize, Min Length)']}
                                />
                                <NodeDoc 
                                    title="Batch Item"
                                    desc="Links Target, Caption, and Reference configs for batching."
                                    inputs={['From Batch List']}
                                    fields={['Target Config', 'Caption Config', 'Reference Config', 'Caption Dropout']}
                                />
                            </DocSection>
                            
                            <DocSection title="Old Schema Nodes" icon={Box}>
                                <NodeDoc 
                                    title="Old Schema Root"
                                    desc="Root node for the legacy configuration schema."
                                    inputs={['From Script']}
                                    fields={['Connects to: Old Image List, Old Caption List, Old Training Set List']}
                                />
                                <NodeDoc 
                                    title="Old Image/Caption/Ref Items"
                                    desc="Legacy configuration items."
                                    inputs={['From respective Lists']}
                                    fields={['Key', 'Suffix', 'Extension', 'Instruction', 'Target', 'Dropout', 'Resize']}
                                />
                            </DocSection>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export const FlowEditor = () => {
  const [nodes, setNodes] = useState<Node[]>(initialNodes);
  const [edges, setEdges] = useState<Edge[]>(initialEdges);
  const [output, setOutput] = useState<{json: string, cmd: string}>({ json: '', cmd: '' });
  const [clipboard, setClipboard] = useState<Node[]>([]);
  
  // UI State
  const [showPalette, setShowPalette] = useState(true);
  const [showOutput, setShowOutput] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const [lang, setLang] = useState<Language>('en');
  const [theme, setTheme] = useState<Theme>('dark');
  const [isSpacePressed, setIsSpacePressed] = useState(false);
  
  // History
  const [history, setHistory] = useState<{nodes: Node[], edges: Edge[]}[]>([]);
  const [future, setFuture] = useState<{nodes: Node[], edges: Edge[]}[]>([]);

  // Auto-connect / Menu State
  const [contextMenu, setContextMenu] = useState<{x: number, y: number, options: {type: string, label: string}[], sourceId: string, handleId: string} | null>(null);
  const connectingNodeId = useRef<string | null>(null);
  const connectingHandleId = useRef<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { project, setViewport, getViewport } = useReactFlow();

  // Helper for translations
  const t = (key: keyof typeof TRANSLATIONS.en) => TRANSLATIONS[lang][key] || key;

  // Theme Toggle Effect
  useEffect(() => {
      const root = document.documentElement;
      if (theme === 'dark') {
          root.classList.add('dark');
      } else {
          root.classList.remove('dark');
      }
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  const toggleLang = () => setLang(prev => prev === 'en' ? 'cn' : 'en');

  const snapshot = useCallback(() => {
    setHistory(prev => [...prev.slice(-20), { nodes, edges }]); 
    setFuture([]);
  }, [nodes, edges]);

  const onNodesChange: OnNodesChange = useCallback(
    (changes: NodeChange[]) => {
      // If Space is pressed, we ignore position changes for dragged nodes
      // enabling us to 'hijack' the drag to pan the viewport instead.
      if (isSpacePressed) {
          const filtered = changes.filter(c => c.type !== 'position');
          if (filtered.length < changes.length) {
              // Position change blocked.
          }
          if (filtered.length === 0) return;
          if (filtered.some(c => c.type === 'remove')) snapshot();
          setNodes((nds) => applyNodeChanges(filtered, nds));
      } else {
          if (changes.some(c => c.type === 'remove')) snapshot();
          setNodes((nds) => applyNodeChanges(changes, nds));
      }
    },
    [snapshot, isSpacePressed]
  );

  const onEdgesChange: OnEdgesChange = useCallback(
    (changes: EdgeChange[]) => {
      if (changes.some(c => c.type === 'remove')) snapshot();
      setEdges((eds) => applyEdgeChanges(changes, eds));
    },
    [snapshot]
  );

  const onNodeDragStart = useCallback(() => {
      if(!isSpacePressed) snapshot();
  }, [snapshot, isSpacePressed]);

  const onNodeDrag = useCallback((event: React.MouseEvent, node: Node) => {
      if (isSpacePressed) {
          const { x, y, zoom } = getViewport();
          // Pan viewport
          setViewport({
              x: x + event.movementX,
              y: y + event.movementY,
              zoom
          });
      }
  }, [isSpacePressed, getViewport, setViewport]);

  const updateNodeData = useCallback((id: string, key: string, value: any) => {
    setNodes((nds) =>
      nds.map((node) => {
        if (node.id !== id) return node;
        return { ...node, data: { ...node.data, [key]: value } };
      })
    );
  }, [setNodes]);

  const toggleLock = useCallback((id: string) => {
      setNodes((nds) =>
        nds.map((node) => {
            if (node.id !== id) return node;
            const newPinned = !node.data.pinned;
            return {
                ...node,
                // If not pinned, set draggable to undefined so it falls back to global ReactFlow 'nodesDraggable' setting
                draggable: !newPinned ? undefined : false,
                data: { ...node.data, pinned: newPinned }
            };
        })
      );
  }, [setNodes]);

  const onUndo = useCallback(() => {
    if (history.length === 0) return;
    const previous = history[history.length - 1];
    setFuture(prev => [{ nodes, edges }, ...prev]);
    setHistory(history.slice(0, -1));
    setNodes(previous.nodes);
    setEdges(previous.edges);
  }, [history, nodes, edges]);

  const onRedo = useCallback(() => {
    if (future.length === 0) return;
    const next = future[0];
    setFuture(future.slice(1));
    setHistory(prev => [...prev, { nodes, edges }]);
    setNodes(next.nodes);
    setEdges(next.edges);
  }, [future, nodes, edges]);

  const saveWorkflow = () => {
      const data = { nodes, edges, timestamp: Date.now(), version: "1.0" };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `workflow_${new Date().toISOString().slice(0,10)}.json`;
      link.click();
      URL.revokeObjectURL(url);
  };

  const loadWorkflowFile = (file: File) => {
      const reader = new FileReader();
      reader.onload = (e) => {
          try {
              const content = e.target?.result as string;
              const data = JSON.parse(content);
              if (data.nodes && data.edges) {
                  snapshot();
                  setNodes(data.nodes);
                  setEdges(data.edges);
              } else {
                  alert("Invalid workflow file format.");
              }
          } catch (err) {
              alert("Failed to parse JSON file.");
          }
      };
      reader.readAsText(file);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) loadWorkflowFile(e.target.files[0]);
      if(fileInputRef.current) fileInputRef.current.value = '';
  };
  
  const runTraining = async () => {
      const scriptNode = nodes.find(n => n.type === 'scriptNode');
      const scriptName = scriptNode?.data.scriptName;
      
      if (!scriptName) {
          alert("No script selected! Please ensure a Script Loader node exists.");
          return;
      }

      try {
          // Assuming the backend is running on default Gradio/Uvicorn port 7860
          const response = await fetch('http://127.0.0.1:7860/api/run', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                  script_name: scriptName,
                  config: JSON.parse(output.json)
              })
          });
          
          const res = await response.json();
          if(res.status === 'success') {
              alert(`Training started successfully!\nCommand: ${res.command}`);
          } else {
              alert(`Error starting training: ${res.message}`);
          }
      } catch (e) {
          console.error(e);
          alert("Failed to connect to backend. Please ensure the python script is running (host: 127.0.0.1, port: 7860).");
      }
  };

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback((event: React.DragEvent) => {
      event.preventDefault();
      if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
           loadWorkflowFile(event.dataTransfer.files[0]);
      }
    }, [snapshot]
  );

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        const isCtrl = e.ctrlKey || e.metaKey;
        const target = e.target as HTMLElement;
        const isInput = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT';

        if (e.code === 'Space' && !e.repeat && !isInput) {
             e.preventDefault();
             setIsSpacePressed(true);
        }

        if (isCtrl && e.key.toLowerCase() === 'c' && !isInput) {
            const selected = nodes.filter(n => n.selected);
            if (selected.length > 0) setClipboard(selected);
        }

        if (isCtrl && e.key.toLowerCase() === 'v' && !isInput && clipboard.length > 0) {
            snapshot();
            setNodes(nds => nds.map(n => ({...n, selected: false})));
            const newNodes = clipboard.map(node => ({
                ...node,
                id: `${node.type}_${Math.random().toString(36).substr(2, 6)}`,
                position: { x: node.position.x + 50, y: node.position.y + 50 },
                selected: true,
                data: { ...node.data }
            }));
            setNodes(nds => [...nds, ...newNodes]);
        }

        if (isCtrl && e.key.toLowerCase() === 'z' && !isInput) {
            e.preventDefault();
            e.shiftKey ? onRedo() : onUndo();
        }
        if (isCtrl && e.key.toLowerCase() === 'y' && !isInput) {
            e.preventDefault();
            onRedo();
        }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
        if (e.code === 'Space') {
            setIsSpacePressed(false);
        }
    };

    const handleBlur = () => setIsSpacePressed(false);

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('blur', handleBlur);
    return () => {
        window.removeEventListener('keydown', handleKeyDown);
        window.removeEventListener('keyup', handleKeyUp);
        window.removeEventListener('blur', handleBlur);
    };
  }, [nodes, clipboard, snapshot, onUndo, onRedo]);

  const deleteNode = useCallback((id: string) => {
      snapshot();
      setNodes(nds => nds.filter(n => n.id !== id));
      setEdges(eds => eds.filter(e => e.source !== id && e.target !== id));
  }, [snapshot, setNodes, setEdges]);

  const copyNode = useCallback((id: string) => {
      snapshot();
      const node = nodes.find(n => n.id === id);
      if(!node) return;
      const newNode = {
          ...node,
          id: `${node.type}_${Math.random().toString(36).substr(2,6)}`,
          position: { x: node.position.x + 50, y: node.position.y + 50 },
          selected: true
      };
      setNodes(nds => [...nds.map(n => ({...n, selected: false})), newNode]);
  }, [nodes, snapshot, setNodes]);

  const onConnect = useCallback((params: Connection) => {
      snapshot();
      setEdges((eds) => addEdge(params, eds.filter(e => !(e.target === params.target && e.targetHandle === params.targetHandle))));
  }, [setEdges, snapshot]);

  useEffect(() => {
    const result = parseGraph(nodes, edges);
    setOutput({ json: JSON.stringify(result.config, null, 2), cmd: result.command });
  }, [nodes, edges]);

  // Extended addNode to support auto-wiring
  const addNode = (type: string, label: string, position?: {x: number, y: number}, sourceInfo?: { nodeId: string, handleId: string }) => {
      snapshot();
      const id = `${type}_${Math.random().toString(36).substr(2, 6)}`;
      const pos = position || { x: Math.random() * 400 + 100, y: Math.random() * 400 + 100 };
      
      setNodes((nds) => nds.concat({
        id, type, position: pos, data: { label },
      }));

      if(sourceInfo) {
          setEdges((eds) => addEdge({
              source: sourceInfo.nodeId,
              sourceHandle: sourceInfo.handleId,
              target: id,
              targetHandle: 'in', // Assume standard input is 'in'
          }, eds));
      }
  };

  // --- Auto-Connect Logic ---
  const onConnectStart = useCallback((_: any, params: OnConnectStartParams) => {
      connectingNodeId.current = params.nodeId;
      connectingHandleId.current = params.handleId;
  }, []);

  const onConnectEnd = useCallback((event: any) => {
    const targetIsPane = event.target.classList.contains('react-flow__pane');
    
    if (targetIsPane && connectingNodeId.current && connectingHandleId.current) {
        const srcNode = nodes.find(n => n.id === connectingNodeId.current);
        if(!srcNode) return;

        const mapping = NODE_CONNECTION_MAP[srcNode.type || ''];
        if(mapping) {
            // Find specific handle mapping or default
            const options = mapping[connectingHandleId.current] || mapping['__default__'];
            
            if(options && options.length > 0) {
                // Calculate position
                const { top, left } = event.target.getBoundingClientRect();
                const position = project({ 
                    x: event.clientX - left, 
                    y: event.clientY - top 
                });

                if(options.length === 1) {
                    // Auto Create
                    addNode(options[0].type, options[0].label, position, { 
                        nodeId: connectingNodeId.current, 
                        handleId: connectingHandleId.current 
                    });
                } else {
                    // Show Menu
                    setContextMenu({
                        x: event.clientX,
                        y: event.clientY,
                        options,
                        sourceId: connectingNodeId.current,
                        handleId: connectingHandleId.current
                    });
                }
            }
        }
    }
    // Reset
    connectingNodeId.current = null;
    connectingHandleId.current = null;
  }, [nodes, project]);

  const onPaneClick = useCallback(() => setContextMenu(null), []);

  const handleMenuSelect = (option: {type: string, label: string}) => {
      if(contextMenu) {
        // We need to re-calculate project here since contextMenu uses client coords
        const reactFlowPane = document.querySelector('.react-flow__pane');
        if(reactFlowPane) {
             const { top, left } = reactFlowPane.getBoundingClientRect();
             const position = project({ 
                x: contextMenu.x - left, 
                y: contextMenu.y - top 
            });
            addNode(option.type, option.label, position, { 
                nodeId: contextMenu.sourceId, 
                handleId: contextMenu.handleId 
            });
        }
      }
      setContextMenu(null);
  };

  // Helper for Button UI
  const IconButton = ({ onClick, active, title, icon: Icon, color = 'blue' }: any) => (
      <button 
        onClick={onClick}
        title={title}
        className={`p-2 rounded-lg transition-all duration-200 group
            ${active 
                ? `bg-${color}-500/20 text-${color}-500 ring-1 ring-${color}-500/50` 
                : 'text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/10'
            }`}
      >
          <Icon size={18} />
      </button>
  );

  return (
    <FlowContext.Provider value={{
        updateNodeData, deleteNode, copyNode, toggleLock, undo: onUndo, redo: onRedo,
        canUndo: history.length > 0, canRedo: future.length > 0,
        lang, theme
    }}>
        <div className="relative h-screen w-screen bg-zinc-200 dark:bg-zinc-950 overflow-hidden transition-colors duration-300" onDrop={onDrop} onDragOver={onDragOver}>
            
            {/* Minimalist Left Sidebar */}
            <div className="absolute top-4 left-4 z-50 flex flex-col items-center gap-1.5 py-2 px-1 rounded-xl shadow-lg border border-zinc-300 dark:border-zinc-800 bg-white/30 dark:bg-black/20 backdrop-blur-md w-12 transition-all">
                <IconButton onClick={() => { setShowPalette(!showPalette); setShowOutput(false); setShowAbout(false); }} active={showPalette} title={t('palette')} icon={LayoutGrid} color="blue" />
                <IconButton onClick={() => { setShowOutput(!showOutput); setShowPalette(false); setShowAbout(false); }} active={showOutput} title={t('output')} icon={Terminal} color="orange" />
                
                <div className="w-6 h-px bg-zinc-300 dark:bg-zinc-700 my-1"></div>
                
                <IconButton onClick={saveWorkflow} title={t('save')} icon={Save} />
                <IconButton onClick={() => fileInputRef.current?.click()} title={t('load')} icon={FolderOpen} />
                <input type="file" ref={fileInputRef} className="hidden" accept=".json" onChange={handleFileSelect} />

                <div className="w-6 h-px bg-zinc-300 dark:bg-zinc-700 my-1"></div>

                {/* RUN Button */}
                <IconButton onClick={runTraining} title="Run Training" icon={Play} color="emerald" />

                <div className="w-6 h-px bg-zinc-300 dark:bg-zinc-700 my-1"></div>

                <IconButton onClick={() => { setShowAbout(true); setShowPalette(false); setShowOutput(false); }} active={showAbout} title="About" icon={Info} color="purple" />

                <div className="w-6 h-px bg-zinc-300 dark:bg-zinc-700 my-1"></div>
                
                <IconButton onClick={toggleTheme} title={theme === 'dark' ? "Light Mode" : "Dark Mode"} icon={theme === 'dark' ? Moon : Sun} />
                <button 
                    onClick={toggleLang}
                    title="Switch Language"
                    className="p-2 rounded-lg text-xs font-bold text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
                >
                    {lang === 'en' ? 'EN' : '中'}
                </button>
            </div>

            {/* Context Menu for Node Creation */}
            {contextMenu && (
                <div style={{ top: contextMenu.y, left: contextMenu.x }} className="absolute z-[60] bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-lg shadow-xl p-1 min-w-[150px] flex flex-col gap-0.5 animate-in fade-in zoom-in-95 duration-100 origin-top-left">
                    <div className="px-2 py-1 text-[10px] uppercase font-bold text-zinc-400 dark:text-zinc-500 border-b border-zinc-100 dark:border-zinc-700/50 mb-1">Create Node</div>
                    {contextMenu.options.map(opt => (
                        <button 
                            key={opt.type} 
                            onClick={() => handleMenuSelect(opt)} 
                            className="text-left px-2 py-1.5 text-xs text-zinc-700 dark:text-zinc-200 hover:bg-blue-50 dark:hover:bg-blue-900/30 hover:text-blue-600 dark:hover:text-blue-400 rounded transition-colors"
                        >
                            {opt.label}
                        </button>
                    ))}
                </div>
            )}

            {/* Main Canvas */}
            <ReactFlow
                nodes={nodes}
                edges={edges}
                nodeTypes={nodeTypes}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onNodeDragStart={onNodeDragStart}
                onNodeDrag={onNodeDrag}
                onConnect={onConnect}
                onConnectStart={onConnectStart}
                onConnectEnd={onConnectEnd}
                onPaneClick={onPaneClick}
                deleteKeyCode={['Backspace', 'Delete']}
                selectionKeyCode="Shift"
                selectionMode={SelectionMode.Partial}
                multiSelectionKeyCode={['Control', 'Meta', 'Shift']}
                nodesDraggable={!isSpacePressed}
                panOnDrag={true}
                defaultEdgeOptions={defaultEdgeOptions}
                fitView
                minZoom={0.1}
                connectionRadius={40}
                proOptions={{ hideAttribution: true }}
                className="absolute inset-0"
            >
                <Background color={theme === 'dark' ? "#27272a" : "#d4d4d8"} gap={20} />
            </ReactFlow>

            {/* About & Docs Modal Overlay */}
            {showAbout && <AboutModal onClose={() => setShowAbout(false)} />}

            {/* Floating Palette Panel */}
            {showPalette && (
                <div className="absolute left-20 top-4 bottom-4 w-80 bg-white/30 dark:bg-zinc-900/40 backdrop-blur-sm border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-2xl flex flex-col z-40 animate-in slide-in-from-left-4 fade-in duration-200">
                    <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex justify-between items-center bg-white/70 dark:bg-zinc-900/70 rounded-t-2xl">
                        <h2 className="text-zinc-600 dark:text-zinc-400 text-xs font-bold uppercase tracking-wider flex items-center gap-2">
                            <LayoutGrid size={14}/> {t('palette')}
                        </h2>
                        <button onClick={() => setShowPalette(false)} className="text-zinc-400 hover:text-zinc-900 dark:hover:text-white"><X size={14}/></button>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 scrollbar-thin">
                        <div className="flex gap-2">
                            <button onClick={onUndo} disabled={history.length===0} className="flex-1 bg-white/80 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 p-2 rounded-lg text-xs font-medium hover:bg-white dark:hover:bg-zinc-700 disabled:opacity-50 border border-zinc-200 dark:border-zinc-700 transition-all active:scale-95 shadow-sm">{t('undo')}</button>
                            <button onClick={onRedo} disabled={future.length===0} className="flex-1 bg-white/80 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 p-2 rounded-lg text-xs font-medium hover:bg-white dark:hover:bg-zinc-700 disabled:opacity-50 border border-zinc-200 dark:border-zinc-700 transition-all active:scale-95 shadow-sm">{t('redo')}</button>
                        </div>

                        {/* Helper to render palette buttons */}
                        {[
                            { title: t('core'), items: [
                                { id: 'directoryNode', label: t('dir'), color: 'blue' },
                                { id: 'loraNode', label: t('lora'), color: 'purple' },
                                { id: 'miscNode', label: t('misc'), color: 'slate' }
                            ]},
                            { title: t('old_schema'), items: [
                                { id: 'oldSchemaRoot', label: t('old_root'), color: 'amber' },
                                { id: 'oldImageListNode', label: t('old_image_list'), color: 'amber' },
                                { id: 'oldImageItemNode', label: t('old_image_item'), color: 'amber' },
                                { id: 'oldCaptionListNode', label: t('old_caption_list'), color: 'amber' },
                                { id: 'oldCaptionItemNode', label: t('old_caption_item'), color: 'amber' },
                                { id: 'oldRefImageListNode', label: t('old_ref_list'), color: 'orange' },
                                { id: 'oldRefImageItemNode', label: t('old_ref_item'), color: 'orange' },
                                { id: 'oldTrainingSetListNode', label: t('old_train_list'), color: 'indigo' },
                                { id: 'oldTrainingSetItemNode', label: t('old_train_item'), color: 'indigo' },
                                { id: 'oldLayoutListNode', label: t('old_layout_list'), color: 'teal' },
                                { id: 'oldLayoutItemNode', label: t('old_layout_item'), color: 'teal' },
                            ], grid: true },
                            { title: t('structure'), items: [
                                { id: 'datasetListNode', label: t('ds_list'), color: 'cyan' },
                                { id: 'datasetConfigNode', label: t('ds_conf'), color: 'cyan' }
                            ]},
                            { title: t('components'), items: [
                                { id: 'imageListNode', label: t('img_list'), color: 'emerald' },
                                { id: 'imageConfigNode', label: t('img_item'), color: 'emerald' },
                                { id: 'targetListNode', label: t('tgt_list'), color: 'teal' },
                                { id: 'targetConfigNode', label: t('tgt_item'), color: 'teal' },
                                { id: 'referenceListNode', label: t('ref_list'), color: 'orange' },
                                { id: 'referenceConfigNode', label: t('ref_item'), color: 'orange' },
                                { id: 'referenceEntryNode', label: t('ref_src'), color: 'orange' },
                                { id: 'captionListNode', label: t('cap_list'), color: 'pink' },
                                { id: 'captionConfigNode', label: t('cap_item'), color: 'pink' },
                                { id: 'batchListNode', label: t('batch_list'), color: 'indigo' },
                                { id: 'batchConfigNode', label: t('batch_item'), color: 'indigo' },
                            ], grid: true }
                        ].map((section, idx) => (
                            <div key={idx}>
                                <h3 className="text-zinc-500 dark:text-zinc-300 text-[10px] uppercase font-bold mb-2 px-1">{section.title}</h3>
                                <div className={section.grid ? "grid grid-cols-2 gap-2" : "space-y-2"}>
                                    {section.items.map(item => (
                                        <button 
                                            key={item.id}
                                            onClick={() => addNode(item.id, item.label)} 
                                            className={`w-full bg-white dark:bg-zinc-800 text-${item.color}-700 dark:text-${item.color}-200 text-xs p-2.5 rounded-lg border border-zinc-200 dark:border-zinc-700 text-left hover:border-${item.color}-400 dark:hover:border-${item.color}-500 hover:shadow-md transition-all`}
                                        >
                                            {item.label}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Floating Output Panel */}
            {showOutput && (
                <div className="absolute left-20 top-4 bottom-4 w-[500px] bg-white/20 dark:bg-zinc-900/50 backdrop-blur-sm border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-2xl flex flex-col z-40 animate-in slide-in-from-left-4 fade-in duration-200">
                    <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex justify-between items-center bg-white/70 dark:bg-zinc-900/70 rounded-t-2xl">
                        <h2 className="text-zinc-600 dark:text-zinc-400 text-xs font-bold uppercase tracking-wider flex items-center gap-2">
                            <Terminal size={14}/> {t('output')}
                        </h2>
                        <button onClick={() => setShowOutput(false)} className="text-zinc-400 hover:text-zinc-900 dark:hover:text-white"><X size={14}/></button>
                    </div>
                    
                    <div className="flex-1 overflow-hidden p-5 flex flex-col gap-6">
                        <div className="flex-shrink-0">
                            <div className="flex justify-between items-center mb-2">
                                <label className="text-[10px] uppercase text-blue-500 font-bold tracking-wider">{t('cmd')}</label>
                                <button onClick={() => navigator.clipboard.writeText(output.cmd)} className="text-[10px] bg-zinc-200 dark:bg-zinc-800 px-2 py-1 rounded text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors">{t('copy')}</button>
                            </div>
                            <div className="bg-white/90 dark:bg-black/80 p-4 rounded-xl border border-zinc-200 dark:border-zinc-700/50 text-green-600 dark:text-green-400 font-mono text-xs break-all selection:bg-green-200 dark:selection:bg-green-900 selection:text-black dark:selection:text-white leading-relaxed shadow-sm">
                                {output.cmd}
                            </div>
                        </div>

                        <div className="flex-1 flex flex-col min-h-0">
                            <div className="flex justify-between items-center mb-2 flex-shrink-0">
                                <label className="text-[10px] uppercase text-orange-500 font-bold tracking-wider">{t('json')}</label>
                                <button onClick={() => navigator.clipboard.writeText(output.json)} className="text-[10px] bg-zinc-200 dark:bg-zinc-800 px-2 py-1 rounded text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors">{t('copy')}</button>
                            </div>
                            <pre className="flex-1 overflow-auto bg-white/90 dark:bg-black/80 p-4 rounded-xl border border-zinc-200 dark:border-zinc-700/50 text-zinc-600 dark:text-zinc-300 font-mono text-[10px] scrollbar-thin selection:bg-orange-200 dark:selection:bg-orange-900 selection:text-black dark:selection:text-white shadow-sm">
                                {output.json}
                            </pre>
                        </div>
                    </div>
                </div>
            )}
        </div>
    </FlowContext.Provider>
  );
};